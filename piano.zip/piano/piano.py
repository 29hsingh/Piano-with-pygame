import numpy as np
from scipy.io.wavfile import write
import pygame
from pygame.locals import *
import os
pygame.mixer.init()
samplerate = 44100

def get_piano_notes():
    # White keys are in Uppercase and black keys (sharps) are in lowercase
    octave = ['C', 'c', 'D', 'd', 'E', 'F', 'f', 'G', 'g', 'A', 'a', 'B']
    base_freq = 261.63
    note_freqs = {octave[i]: base_freq * pow(2, (i/12)) for i in range(len(octave))}
    note_freqs[''] = 0.0
    return note_freqs

def get_wave(freq, duration=0.5):
    global samplerate
    amplitude = 4096
    t = np.linspace(0, duration, int(samplerate * duration))
    wave = amplitude * np.sin(2 * np.pi * freq * t)
    return wave

def get_song_data(music_notes):
    note_freqs = get_piano_notes()
    song = [get_wave(note_freqs[note]) for note in music_notes.split('-')]
    song = np.concatenate(song)
    return song

def draw_rect_alpha(surface, color, rect):
    shape_surf = pygame.Surface(pygame.Rect(rect).size, pygame.SRCALPHA)
    pygame.draw.rect(shape_surf, color, shape_surf.get_rect())
    surface.blit(shape_surf, rect)

def start():
    # music_notes = 'C-C-G-G-A-A-G--F-F-E-E-D-D-C--G-G-F-F-E-E-D--G-G-F-F-E-E-D--C-C-G-G-A-A-G--F-F-E-E-D-D-C'
    key = ""
    octave = ['C', 'c', 'D', 'd', 'E', 'F', 'f', 'G', 'g', 'A', 'a', 'B']
    (WIDTH, HEIGHT) = (1000, 700)
    WIN = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption('Piano')
    BG = pygame.transform.scale(pygame.image.load(os.path.join("assets", "keys.jpg")), (WIDTH, HEIGHT))
    draw_rect_alpha(WIN, (0, 0, 255, 127), (55, 90, 140, 140))
    running = True
    while running:
        WIN.blit(BG, (0, 0))
        draw_rect_alpha(WIN, (0, 0, 0, 127), (113, 368, 100, 140))
        draw_rect_alpha(WIN, (0, 0, 0, 127), (228, 368, 100, 140))
        draw_rect_alpha(WIN, (0, 0, 0, 127), (342, 368, 100, 140))
        draw_rect_alpha(WIN, (0, 0, 0, 127), (453, 368, 100, 140))
        draw_rect_alpha(WIN, (0, 0, 0, 127), (565, 368, 100, 140))
        draw_rect_alpha(WIN, (0, 0, 0, 127), (678, 368, 100, 140))
        draw_rect_alpha(WIN, (0, 0, 0, 127), (789, 368, 100, 140))

        draw_rect_alpha(WIN, (0, 0, 0, 127), (173, 218, 70, 140))
        draw_rect_alpha(WIN, (0, 0, 0, 127), (310, 218, 70, 140))
        draw_rect_alpha(WIN, (0, 0, 0, 127), (510, 218, 70, 140))
        draw_rect_alpha(WIN, (0, 0, 0, 127), (640, 218, 70, 140))
        draw_rect_alpha(WIN, (0, 0, 0, 127), (768, 218, 70, 140))

        mouse = pygame.mouse.get_pos()
        pygame.display.flip()
        key = ""
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            if event.type == KEYDOWN:
                if event.key == K_d:
                    mods = pygame.key.get_mods()
                    if mods & pygame.KMOD_SHIFT:
                        key = 'd'
                    else:
                        key = 'D'
                elif event.key == K_c:
                    mods = pygame.key.get_mods()
                    if mods & pygame.KMOD_SHIFT:
                        key = 'c'
                    else:
                        key = 'C'
                elif event.key == K_e:
                    mods = pygame.key.get_mods()
                    if not mods & pygame.KMOD_SHIFT:
                        key = 'E'
                if event.key == K_f:
                    mods = pygame.key.get_mods()
                    if mods & pygame.KMOD_SHIFT:
                        key = 'f'
                    else:
                        key = 'F'
                if event.key == K_g:
                    mods = pygame.key.get_mods()
                    if mods & pygame.KMOD_SHIFT:
                        key = 'g'
                    else:
                        key = 'G'
                if event.key == K_a:
                    mods = pygame.key.get_mods()
                    if mods & pygame.KMOD_SHIFT:
                        key = 'a'
                    else:
                        key = 'A'
                elif event.key == K_b:
                    mods = pygame.key.get_mods()
                    if not mods & pygame.KMOD_SHIFT:
                        key = 'B'
            if event.type == MOUSEBUTTONUP:
                if mouse[0] in range(228, 328) and mouse[1] in range(368, 508):
                    key = 'D'
                elif mouse[0] in range(113, 213) and mouse[1] in range(368, 508):
                    key = 'C'
                elif mouse[0] in range(342, 442) and mouse[1] in range(368, 508):
                    key = 'E'
                elif mouse[0] in range(453, 553) and mouse[1] in range(368, 508):
                    key = 'F'
                elif mouse[0] in range(565, 665) and mouse[1] in range(368, 508):
                    key = 'G'
                elif mouse[0] in range(678, 778) and mouse[1] in range(368, 508):
                    key = 'A'
                elif mouse[0] in range(789, 889) and mouse[1] in range(368, 508):
                    key = 'B'

                elif mouse[0] in range(173, 243) and mouse[1] in range(218, 358):
                    key = 'c'
                elif mouse[0] in range(310, 380) and mouse[1] in range(218, 358):
                    key = 'd'
                elif mouse[0] in range(510, 580) and mouse[1] in range(218, 358):
                    key = 'f'
                elif mouse[0] in range(640, 710) and mouse[1] in range(218, 358):
                    key = 'g'
                elif mouse[0] in range(768, 838) and mouse[1] in range(218, 358):
                    key = 'a'
        if key in octave:
            music_notes = key
            data = get_song_data(music_notes)
            data = data * (16300 / np.max(data))
            write('mysound.wav', samplerate, data.astype(np.int16))
            my_sound = pygame.mixer.Sound('mysound.wav')
            my_sound.play()
            pygame.time.wait(int(my_sound.get_length() * 100))
start()